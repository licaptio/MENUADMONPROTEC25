PROVSOFT INVENTARIO - APP VIRGEN POR CONFIGURACIÓN JSON

Flujo actual:
1. La app abre sin configuración de sucursal.
2. Siempre pide cargar un archivo JSON.
3. No usa localStorage.
4. No guarda configuración en la computadora.
5. No exporta configuración desde la app.
6. Solo un usuario autorizado en Firebase puede aplicar la configuración.

Archivo incluido:
- config_zapata.json

Para instalar en una sucursal:
1. Abrir la app.
2. Entrar al menú ⚙️ Configuración.
3. Cargar el JSON de la sucursal.
4. Validar configuración.
5. Aplicar configuración.
6. La app consulta Firestore usando las rutas del JSON cargado.

Para otra sucursal, crear otro JSON con sus rutas Firestore.
