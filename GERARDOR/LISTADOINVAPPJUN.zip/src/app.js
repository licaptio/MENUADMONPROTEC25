import { store } from "./state/store.js";
import { $ } from "./utils/format.js";
import { hoyISO, sumarDias, obtenerSemanaActualInput, obtenerRangoDomingoSabadoDesdeWeek, crearFechasSemana, fechaCorta } from "./utils/dates.js";
import { setStatus, setProgress, ocultarLoader } from "./ui/loader.js";
import { pintarTabla, cambiarVista } from "./ui/tableRenderer.js";
import { aplicarTextosConfig, inicializarConfigProtegida } from "./ui/settingsPanel.js";
import { cargarInventarioInicial, cargarProveedoresAutorizadosPivot, consultarSalidas, consultarEntradas } from "./services/firestoreService.js";

function obtenerRangoSemana() {
  const selectorSemana = $("selectorSemana");
  const valorWeek = selectorSemana?.value || obtenerSemanaActualInput();
  if (selectorSemana && !selectorSemana.value) selectorSemana.value = valorWeek;
  const rango = obtenerRangoDomingoSabadoDesdeWeek(valorWeek, store.config.fechaInicioMinima);
  const acumuladoAnteriorFin = sumarDias(rango.inicio, -1);
  store.rangoSemanaActual = { inicio: rango.inicio, fin: rango.fin, acumuladoAnteriorFin };
  if ($("fechaInicio")) $("fechaInicio").value = rango.inicio;
  if ($("fechaFin")) $("fechaFin").value = rango.fin;
  return store.rangoSemanaActual;
}

function asegurarRow(mapa, item) {
  const key = item.codigoKey || String(item.nombre || "").toLowerCase();
  if (!mapa.has(key)) mapa.set(key, { codigo: item.codigo, codigoKey: item.codigoKey, nombre: item.nombre, inviniOriginal: 0, entradasAcumuladasAnteriores: 0, salidasAcumuladasAnteriores: 0, inviniSemana: 0, entradasPorFecha: {}, salidasPorFecha: {}, totalEntradasSemana: 0, totalSalidasSemana: 0, existenciaFinalSemana: 0 });
  const row = mapa.get(key);
  if (!row.codigo && item.codigo) row.codigo = item.codigo;
  if (!row.nombre && item.nombre) row.nombre = item.nombre;
  return row;
}

function construirPivot(detalleSemana, detalleAcumuladoAnterior, entradasSemana, entradasAcumuladoAnterior, inicioSemana, finSemana) {
  const mapa = new Map();
  store.fechasColumnas = crearFechasSemana(inicioSemana, finSemana);
  Object.keys(store.inventarioInicialOriginal).forEach(key => {
    const inv = store.inventarioInicialOriginal[key];
    mapa.set(key, { codigo: inv.codigo, codigoKey: inv.codigoKey, nombre: inv.nombre, inviniOriginal: Number(inv.inviniOriginal || 0), entradasAcumuladasAnteriores: 0, salidasAcumuladasAnteriores: 0, inviniSemana: Number(inv.inviniOriginal || 0), entradasPorFecha: {}, salidasPorFecha: {}, totalEntradasSemana: 0, totalSalidasSemana: 0, existenciaFinalSemana: Number(inv.inviniOriginal || 0) });
  });
  entradasAcumuladoAnterior.forEach(item => { asegurarRow(mapa, item).entradasAcumuladasAnteriores += Number(item.cantidad || 0); });
  detalleAcumuladoAnterior.forEach(item => { asegurarRow(mapa, item).salidasAcumuladasAnteriores += Number(item.cantidad || 0); });
  mapa.forEach(row => { row.inviniSemana = Number(row.inviniOriginal || 0) + Number(row.entradasAcumuladasAnteriores || 0) - Number(row.salidasAcumuladasAnteriores || 0); row.existenciaFinalSemana = row.inviniSemana; });
  entradasSemana.forEach(item => { const row = asegurarRow(mapa, item); row.entradasPorFecha[item.fecha] = Number(row.entradasPorFecha[item.fecha] || 0) + Number(item.cantidad || 0); row.totalEntradasSemana += Number(item.cantidad || 0); row.existenciaFinalSemana = Number(row.inviniSemana || 0) + Number(row.totalEntradasSemana || 0) - Number(row.totalSalidasSemana || 0); });
  detalleSemana.forEach(item => { const row = asegurarRow(mapa, item); row.salidasPorFecha[item.fecha] = Number(row.salidasPorFecha[item.fecha] || 0) + Number(item.cantidad || 0); row.totalSalidasSemana += Number(item.cantidad || 0); row.existenciaFinalSemana = Number(row.inviniSemana || 0) + Number(row.totalEntradasSemana || 0) - Number(row.totalSalidasSemana || 0); });
  store.registrosPivot = Array.from(mapa.values()).sort((a, b) => String(a.nombre).localeCompare(String(b.nombre), "es"));
}

async function cargarSalidasZapata() {
  try {
    if (!store.config) {
      setStatus("Carga el archivo JSON de configuración para iniciar.");
      cambiarVista("config");
      return;
    }
    const rango = obtenerRangoSemana();
    setStatus(`Cargando inventario inicial ${store.config.conteoIdInventario}...`); setProgress(8);
    const inv = await cargarInventarioInicial(store.config);
    store.inventarioInicialOriginal = inv.inventario;
    setStatus(`Inventario inicial cargado. Usuarios: ${inv.usuariosLeidos}. Partidas: ${inv.partidasLeidas}.`);
    store.proveedoresAutorizadosPivot = await cargarProveedoresAutorizadosPivot(store.config);

    setStatus(`Consultando semana ${rango.inicio} a ${rango.fin}. Acumulado anterior hasta ${rango.acumuladoAnteriorFin}...`); setProgress(25);
    const consultaSemana = await consultarSalidas(store.config, rango.inicio, rango.fin);
    const consultaEntradasSemana = await consultarEntradas(store.config, store.proveedoresAutorizadosPivot, rango.inicio, rango.fin);
    setProgress(55);

    let consultaAcumuladoAnterior = { detalle: [], totalDocs: 0 };
    let consultaEntradasAcumuladoAnterior = { detalle: [], totalDocs: 0 };
    if (rango.acumuladoAnteriorFin >= store.config.fechaBaseInventario) {
      consultaAcumuladoAnterior = await consultarSalidas(store.config, store.config.fechaBaseInventario, rango.acumuladoAnteriorFin);
      consultaEntradasAcumuladoAnterior = await consultarEntradas(store.config, store.proveedoresAutorizadosPivot, store.config.fechaBaseInventario, rango.acumuladoAnteriorFin);
    }
    setProgress(75);

    store.registrosDetalleSemana = consultaSemana.detalle;
    store.registrosDetalleAcumuladoAnterior = consultaAcumuladoAnterior.detalle;
    store.registrosEntradasSemana = consultaEntradasSemana.detalle;
    store.registrosEntradasAcumuladoAnterior = consultaEntradasAcumuladoAnterior.detalle;
    store.registrosDetalleMovimientoSemana = [...store.registrosEntradasSemana, ...store.registrosDetalleSemana].sort((a, b) => a.fecha !== b.fecha ? String(b.fecha).localeCompare(String(a.fecha)) : String(a.tipo).localeCompare(String(b.tipo)));

    construirPivot(store.registrosDetalleSemana, store.registrosDetalleAcumuladoAnterior, store.registrosEntradasSemana, store.registrosEntradasAcumuladoAnterior, rango.inicio, rango.fin);
    
    pintarTabla();
    setProgress(100);
    setStatus(`Consulta lista. Semana: ${fechaCorta(rango.inicio)} a ${fechaCorta(rango.fin)}. Entradas semana: ${store.registrosEntradasSemana.length}. Salidas semana: ${store.registrosDetalleSemana.length}.`);
    ocultarLoader();
  } catch (error) {
    console.error(error);
    setStatus("Error al cargar movimientos Zapata: " + error.message);
    ocultarLoader();
  }
}

function exportarExcel() {
  const rows = store.vistaActual === "detalle"
    ? store.registrosDetalleMovimientoSemana.map(r => ({ Tipo: r.tipo, Fecha: r.fecha, Folio: r.folio, Destino_Proveedor: r.destino, Entrega_Emisor: r.entrega, Recibe_Usuario: r.recibe, RFC_Emisor: r.rfc_emisor, Razon_Social_Emisor: r.razon_social_emisor, Alias_Pivot: r.alias_pivot, Partida: r.partida, Codigo: r.codigo, Nombre: r.nombre, Cantidad: r.cantidad }))
    : store.registrosPivot.map(r => { const obj = { Codigo: r.codigo, Nombre: r.nombre, "INVINI SEMANA": Number(r.inviniSemana || 0) }; store.fechasColumnas.forEach(f => { obj[`ENTRADA ${fechaCorta(f)}`] = Number(r.entradasPorFecha[f] || 0); obj[`SALIDA ${fechaCorta(f)}`] = Number(r.salidasPorFecha[f] || 0); }); obj["TOTAL ENTRADAS"] = Number(r.totalEntradasSemana || 0); obj["TOTAL SALIDAS"] = Number(r.totalSalidasSemana || 0); obj["EXISTENCIA FINAL"] = Number(r.existenciaFinalSemana || 0); return obj; });
  if (!rows.length) return alert("No hay datos para exportar.");
  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.json_to_sheet(rows);
  XLSX.utils.book_append_sheet(wb, ws, store.vistaActual === "detalle" ? "Detalle semana" : "Pivot semana");
  XLSX.writeFile(wb, `movimientos_zapata_${store.vistaActual}_${store.rangoSemanaActual.inicio}_a_${store.rangoSemanaActual.fin}.xlsx`);
}

function inicializarEventos() {
  if ($("selectorSemana")) { $("selectorSemana").value = obtenerSemanaActualInput(); $("selectorSemana").addEventListener("change", cargarSalidasZapata); }
  if ($("fechaInicio")) { $("fechaInicio").value = ""; }
  if ($("fechaFin")) $("fechaFin").value = hoyISO();
  $("btnRecargar").addEventListener("click", cargarSalidasZapata);
  $("btnExportar").addEventListener("click", exportarExcel);
  $("busqueda").addEventListener("input", pintarTabla);
  $("tabResumen").addEventListener("click", () => cambiarVista("resumen"));
  $("tabDetalle").addEventListener("click", () => cambiarVista("detalle"));
inicializarConfigProtegida(cargarSalidasZapata);
}

document.addEventListener("DOMContentLoaded", () => {
  store.config = null;
  aplicarTextosConfig();
  inicializarEventos();
  ocultarLoader();
});
