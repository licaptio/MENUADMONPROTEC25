export const ADMIN_USERS = {
  emails: ["licaptio42@gmail.com"],
  uids: []
};

export const DEFAULT_CONFIG = {
  app: "PROVSOFT_INVENTARIO",
  version: "1.0.0",
  empresaNombre: "",
  sucursalNombre: "",
  appTitulo: "PROVSOFT Inventario",
  loaderSubtitulo: "CARGA CONFIGURACIÓN JSON PARA INICIAR",
  logoSrc: "",
  fechaBaseInventario: "",
  fechaInicioMinima: "",
  conteoIdInventario: "",
  almacenId: "",
  rutas: {
    inventarioUsuarios: "",
    entradas: "",
    salidas: "",
    proveedoresAutorizados: ""
  }
};

export function normalizarConfigJson(json) {
  const rutas = json.rutas || {};

  return {
    ...DEFAULT_CONFIG,
    ...json,
    empresaNombre: json.empresaNombre || json.empresa || DEFAULT_CONFIG.empresaNombre,
    sucursalNombre: json.sucursalNombre || json.sucursal || DEFAULT_CONFIG.sucursalNombre,
    appTitulo: json.appTitulo || json.titulo || DEFAULT_CONFIG.appTitulo,
    loaderSubtitulo: json.loaderSubtitulo || json.subtitulo || DEFAULT_CONFIG.loaderSubtitulo,
    logoSrc: json.logoSrc || json.logo || DEFAULT_CONFIG.logoSrc,
    rutas: {
      inventarioUsuarios: rutas.inventarioUsuarios || json.rutaInventario || "",
      entradas: rutas.entradas || json.rutaEntradas || "",
      salidas: rutas.salidas || json.rutaSalidas || "",
      proveedoresAutorizados: rutas.proveedoresAutorizados || json.rutaProveedores || ""
    }
  };
}

export function validarConfigBasica(config) {
  const faltantes = [];
  if (!config) faltantes.push("configuración JSON");
  if (!config?.empresaNombre) faltantes.push("empresaNombre / empresa");
  if (!config?.appTitulo) faltantes.push("appTitulo / titulo");
  if (!config?.almacenId) faltantes.push("almacenId");
  if (!config?.conteoIdInventario) faltantes.push("conteoIdInventario");
  if (!config?.fechaBaseInventario) faltantes.push("fechaBaseInventario");
  if (!config?.fechaInicioMinima) faltantes.push("fechaInicioMinima");
  if (!config?.rutas?.inventarioUsuarios) faltantes.push("rutas.inventarioUsuarios");
  if (!config?.rutas?.entradas) faltantes.push("rutas.entradas");
  if (!config?.rutas?.salidas) faltantes.push("rutas.salidas");
  if (!config?.rutas?.proveedoresAutorizados) faltantes.push("rutas.proveedoresAutorizados");

  return {
    ok: faltantes.length === 0,
    faltantes
  };
}
