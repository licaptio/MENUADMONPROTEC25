import { db } from "../config/firebase.js";
import { collection, query, where, orderBy, getDocs } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import { normalizarCodigo } from "../utils/format.js";
import { normalizarFecha } from "../utils/dates.js";

function segmentos(path) {
  return String(path || "").split("/").map(x => x.trim()).filter(Boolean);
}

function refRuta(path) {
  const parts = segmentos(path);
  if (!parts.length) throw new Error("Ruta Firestore vacía.");
  return collection(db, ...parts);
}

function rutaInventario(config) {
  return config.rutas?.inventarioUsuarios || config.rutaInventario || `almacenes/${config.almacenId}/Inventarios/${config.conteoIdInventario}/USUARIOS`;
}

function rutaEntradas(config) {
  return config.rutas?.entradas || config.rutaEntradas || `almacenes/${config.almacenId}/${config.entradasColeccion}`;
}

function rutaSalidas(config) {
  return config.rutas?.salidas || config.rutaSalidas || `almacenes/${config.almacenId}/${config.salidasColeccion}`;
}

function rutaProveedores(config) {
  return config.rutas?.proveedoresAutorizados || config.rutaProveedores || `almacenes/${config.almacenId}/${config.proveedoresColeccion}`;
}

export async function cargarProveedoresAutorizadosPivot(config) {
  const out = {};
  const snap = await getDocs(refRuta(rutaProveedores(config)));
  snap.forEach((docu) => {
    const p = docu.data() || {};
    const rfc = String(p.rfc_emisor || docu.id || "").trim().toUpperCase();
    if (!rfc || p.activo === false) return;
    out[rfc] = {
      rfc,
      razon_social_emisor: String(p.razon_social_emisor || "").trim(),
      alias_pivot: String(p.alias_pivot || p.razon_social_emisor || rfc).trim()
    };
  });
  return out;
}

export function obtenerAliasProveedorPivot(mapa, rfc, razonSocial) {
  const key = String(rfc || "").trim().toUpperCase();
  if (key && mapa[key]) return mapa[key].alias_pivot;
  return String(razonSocial || key || "PROVEEDOR").trim();
}

export async function cargarInventarioInicial(config) {
  const inventario = {};
  const usuariosSnap = await getDocs(refRuta(rutaInventario(config)));
  let usuariosLeidos = 0;
  let partidasLeidas = 0;

  for (const usuarioDoc of usuariosSnap.docs) {
    usuariosLeidos++;
    const partidasSnap = await getDocs(refRuta(`${rutaInventario(config)}/${usuarioDoc.id}/PARTIDAS`));
    partidasSnap.forEach((docu) => {
      const p = docu.data() || {};
      if (p.eliminado === true) return;
      const codigoOriginal = String(p.codigo || p.productoId || p.codigoOriginal || "").trim();
      const codigoKey = normalizarCodigo(codigoOriginal);
      const nombre = String(p.descripcion || p.nombre || "").trim();
      const cantidad = Number(p.cantidad || 0);
      if (!codigoKey && !nombre && !cantidad) return;
      const key = codigoKey || nombre.toLowerCase();
      if (!inventario[key]) inventario[key] = { codigo: codigoOriginal, codigoKey, nombre, inviniOriginal: 0, fechaBase: config.fechaBaseInventario };
      inventario[key].inviniOriginal += cantidad;
      if (!inventario[key].codigo && codigoOriginal) inventario[key].codigo = codigoOriginal;
      if (!inventario[key].nombre && nombre) inventario[key].nombre = nombre;
      partidasLeidas++;
    });
  }

  return { inventario, usuariosLeidos, partidasLeidas };
}

export async function consultarSalidas(config, inicio, fin) {
  if (fin < inicio) return { detalle: [], totalDocs: 0 };
  const q = query(refRuta(rutaSalidas(config)), where("fecha", ">=", inicio), where("fecha", "<=", fin), orderBy("fecha", "desc"));
  const snap = await getDocs(q);
  const detalle = [];
  const docsVistos = new Set();

  snap.forEach((documento) => {
    const data = documento.data() || {};
    docsVistos.add(documento.id);
    const fecha = normalizarFecha(data.fecha || data.timestamp || "");
    if (!fecha || fecha < config.fechaInicioMinima) return;
    const articulos = Array.isArray(data.articulos) ? data.articulos : [];

    articulos.forEach((art, idx) => {
      const codigoOriginal = String(art.codigo ?? "").trim();
      const codigoKey = normalizarCodigo(codigoOriginal);
      const nombre = String(art.nombre ?? "").trim();
      const cantidad = Number(art.cantidad || 0);
      if (!codigoKey && !nombre && !cantidad) return;
      detalle.push({
        tipo: "SALIDA",
        docId: documento.id,
        partida: idx + 1,
        folio: String(data.folio || documento.id || "").trim(),
        fecha,
        destino: String(data.destino || "").trim(),
        entrega: String(data.entrega || "").trim(),
        recibe: String(data.recibe || "").trim(),
        folioCincho: String(data.folioCincho || "").trim(),
        proveedor: "",
        alias_pivot: "",
        rfc_emisor: "",
        razon_social_emisor: "",
        codigo: codigoOriginal,
        codigoKey,
        nombre,
        cantidad
      });
    });
  });

  return { detalle, totalDocs: docsVistos.size };
}

export async function consultarEntradas(config, mapaProveedores, inicio, fin) {
  if (fin < inicio) return { detalle: [], totalDocs: 0 };
  const q = query(refRuta(rutaEntradas(config)), where("fecha", ">=", inicio), where("fecha", "<=", fin), orderBy("fecha", "desc"));
  const snap = await getDocs(q);
  const detalle = [];
  const docsVistos = new Set();

  snap.forEach((documento) => {
    const data = documento.data() || {};
    docsVistos.add(documento.id);
    if (data.estado_zapata && data.estado_zapata !== "ENTRADA_GENERADA") return;
    const fecha = normalizarFecha(data.fecha || data.fecha_factura || data.creado_en || data.timestamp || "");
    if (!fecha || fecha < config.fechaInicioMinima) return;
    const rfcEmisor = String(data.rfc_emisor || "").trim().toUpperCase();
    const razonSocialEmisor = String(data.razon_social_emisor || "").trim();
    const aliasPivot = obtenerAliasProveedorPivot(mapaProveedores, rfcEmisor, razonSocialEmisor);
    const articulos = Array.isArray(data.articulos) ? data.articulos : [];

    articulos.forEach((art, idx) => {
      const codigoOriginal = String(art.codigo_interno || "").trim();
      const codigoKey = normalizarCodigo(codigoOriginal);
      const nombre = String(art.descripcion_interna || art.descripcion_factura || "").trim();
      const cantidad = Number(art.cantidad_entrada || 0);
      if (!codigoKey && !nombre && !cantidad) return;
      detalle.push({
        tipo: "ENTRADA",
        docId: documento.id,
        partida: idx + 1,
        folio: String(data.folioEntrada || data.folio || documento.id || "").trim(),
        fecha,
        destino: config.sucursalNombre || config.almacenId || "ALMACÉN",
        entrega: aliasPivot,
        recibe: String(data.usuario || "").trim(),
        folioCincho: "",
        proveedor: aliasPivot,
        rfc_emisor: rfcEmisor,
        razon_social_emisor: razonSocialEmisor,
        alias_pivot: aliasPivot,
        codigo: codigoOriginal,
        codigoKey,
        nombre,
        cantidad
      });
    });
  });

  return { detalle, totalDocs: docsVistos.size };
}
