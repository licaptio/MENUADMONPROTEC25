export const store = {
  config: null,
  registrosDetalleSemana: [],
  registrosDetalleAcumuladoAnterior: [],
  registrosEntradasSemana: [],
  registrosEntradasAcumuladoAnterior: [],
  registrosDetalleMovimientoSemana: [],
  registrosPivot: [],
  fechasColumnas: [],
  inventarioInicialOriginal: {},
  proveedoresAutorizadosPivot: {},
  vistaActual: "resumen",
  rangoSemanaActual: { inicio: "", fin: "", acumuladoAnteriorFin: "" },
  usuarioFirebase: null,
  esAdmin: false
};
