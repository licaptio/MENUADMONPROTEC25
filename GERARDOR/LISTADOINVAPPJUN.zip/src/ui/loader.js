import { $ } from "../utils/format.js";

export function setStatus(msg) {
  if ($("status")) $("status").textContent = msg;
  if ($("loaderMsg")) $("loaderMsg").textContent = msg;
}

export function setProgress(porcentaje) {
  if ($("loaderBar")) $("loaderBar").style.width = Math.max(0, Math.min(100, porcentaje)) + "%";
}

export function ocultarLoader() {
  if ($("loader")) $("loader").classList.add("hide");
}
