import {
  signInWithEmailAndPassword
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";

import { auth } from "../config/firebase.js";
import {
  ADMIN_USERS,
  normalizarConfigJson,
  validarConfigBasica
} from "../config/appConfig.js";

import { store } from "../state/store.js";
import { $ } from "../utils/format.js";
import { cambiarVista } from "./tableRenderer.js";
import { setStatus, setProgress } from "./loader.js";

let configPendiente = null;

function autorizado(user) {
  if (!user) return false;

  const email = String(user.email || "").toLowerCase();

  return (
    ADMIN_USERS.emails.map(x => x.toLowerCase()).includes(email) ||
    ADMIN_USERS.uids.includes(user.uid)
  );
}

async function loginFirebaseConfig() {
  const email = $("cfgEmail")?.value?.trim();
  const password = $("cfgPassword")?.value;

  if (!email) throw new Error("Captura correo Firebase.");
  if (!password) throw new Error("Captura contraseña Firebase.");

  const cred = await signInWithEmailAndPassword(auth, email, password);
  const user = cred.user;

  if (!autorizado(user)) {
    throw new Error("Usuario no autorizado para cargar configuración.");
  }

  store.usuarioFirebase = user;
  store.esAdmin = true;

  return user;
}

function setValue(id, value) {
  if ($(id)) $(id).value = value || "";
}

function rutas(c) {
  return c?.rutas || {};
}

export function aplicarTextosConfig() {
  const c = store.config || configPendiente;

  if (!c) {
    if ($("appTitle")) $("appTitle").textContent = "PROVSOFT Inventario";
    if ($("loaderTitle")) $("loaderTitle").textContent = "PROVSOFT INVENTARIO";
    if ($("loaderSubtitle")) {
      $("loaderSubtitle").textContent =
        "CARGA CONFIGURACIÓN JSON PARA INICIAR";
    }
    if ($("pathInventarioTexto")) {
      $("pathInventarioTexto").textContent = "Sin configuración cargada.";
    }
    if ($("baseTexto")) {
      $("baseTexto").textContent = "Carga un archivo JSON de sucursal.";
    }
    if ($("pathEntradasTexto")) $("pathEntradasTexto").textContent = "";
    return;
  }

  if ($("appTitle")) $("appTitle").textContent = c.appTitulo;
  if ($("loaderTitle")) $("loaderTitle").textContent = c.empresaNombre;
  if ($("loaderSubtitle")) $("loaderSubtitle").textContent = c.loaderSubtitulo;

  if ($("loaderLogo")) {
    $("loaderLogo").src = c.logoSrc || "";
    $("loaderLogo").style.display = c.logoSrc ? "inline-block" : "none";
  }

  if ($("pathInventarioTexto")) {
    $("pathInventarioTexto").textContent =
      `Inventario inicial tomado de: /${rutas(c).inventarioUsuarios}/{usuarioId}/PARTIDAS`;
  }

  if ($("baseTexto")) {
    $("baseTexto").textContent =
      `Base original: ${c.fechaBaseInventario} · Vista semanal domingo a sábado · Inventario inicial visible = existencia final de la semana anterior.`;
  }

  if ($("pathEntradasTexto")) {
    $("pathEntradasTexto").textContent =
      `Entradas tomadas de: /${rutas(c).entradas}`;
  }
}

export function cargarFormularioConfig(config = store.config || configPendiente) {
  const c = config || {};

  setValue("cfgEmpresa", c.empresaNombre);
  setValue("cfgSucursalNombre", c.sucursalNombre);
  setValue("cfgTitulo", c.appTitulo);
  setValue("cfgSubtitulo", c.loaderSubtitulo);
  setValue("cfgLogo", c.logoSrc);
  setValue("cfgAlmacenId", c.almacenId);
  setValue("cfgConteoId", c.conteoIdInventario);
  setValue("cfgFechaBase", c.fechaBaseInventario);
  setValue("cfgFechaInicioMinima", c.fechaInicioMinima);
  setValue("cfgRutaInventario", rutas(c).inventarioUsuarios);
  setValue("cfgRutaEntradas", rutas(c).entradas);
  setValue("cfgRutaSalidas", rutas(c).salidas);
  setValue("cfgRutaProveedores", rutas(c).proveedoresAutorizados);

  if ($("previewLogo")) {
    $("previewLogo").src = c.logoSrc || "";
    $("previewLogo").style.display = c.logoSrc ? "inline-block" : "none";
  }
}

function imprimirResultado(texto, ok = true) {
  if ($("cfgResultado")) {
    $("cfgResultado").textContent = texto;
    $("cfgResultado").classList.toggle("error", !ok);
  }
}

function validarPendiente() {
  const config = configPendiente || store.config;
  const resultado = validarConfigBasica(config);

  if (!resultado.ok) {
    imprimirResultado(
      `Configuración incompleta. Faltan:\n- ${resultado.faltantes.join("\n- ")}`,
      false
    );
    return false;
  }

  imprimirResultado(
    `Configuración válida.
Sucursal: ${config.sucursalNombre || config.almacenId}
Inventario: /${config.rutas.inventarioUsuarios}
Entradas: /${config.rutas.entradas}
Salidas: /${config.rutas.salidas}
Proveedores: /${config.rutas.proveedoresAutorizados}`,
    true
  );

  return true;
}

async function leerArchivoJson(file) {
  if (!file) throw new Error("Selecciona un archivo JSON.");

  const texto = await file.text();
  return JSON.parse(texto);
}

function setControlesActivos(activo) {
  [
    "btnRecargar",
    "btnExportar",
    "selectorSemana",
    "fechaInicio",
    "fechaFin",
    "busqueda"
  ].forEach(id => {
    if ($(id)) $(id).disabled = !activo;
  });
}

export function inicializarConfigProtegida(onConfigChanged) {
  setControlesActivos(false);
  cambiarVista("config");
  setStatus("Carga el archivo JSON de sucursal para iniciar.");
  setProgress(0);

  $("tabConfig")?.addEventListener("click", () => cambiarVista("config"));
  $("btnInfoConfig")?.addEventListener("click", () => cambiarVista("config"));

  $("cfgArchivoJson")?.addEventListener("change", async (ev) => {
    try {
      const json = await leerArchivoJson(ev.target.files?.[0]);

      configPendiente = normalizarConfigJson(json);

      cargarFormularioConfig(configPendiente);
      aplicarTextosConfig();
      validarPendiente();

      imprimirResultado(
        "JSON cargado correctamente. Captura correo y contraseña Firebase para aplicar.",
        true
      );
    } catch (error) {
      configPendiente = null;

      imprimirResultado(
        "Error al leer JSON: " + error.message,
        false
      );
    }
  });

  $("btnValidarConfig")?.addEventListener("click", () => {
    validarPendiente();
  });

  $("btnAplicarJsonConfig")?.addEventListener("click", async () => {
    try {
      await loginFirebaseConfig();

      if (!configPendiente) {
        throw new Error("Primero carga un archivo JSON.");
      }

      if (!validarPendiente()) return;

      store.config = configPendiente;
      configPendiente = null;

      aplicarTextosConfig();
      cargarFormularioConfig(store.config);

      setControlesActivos(true);
      cambiarVista("resumen");

      await onConfigChanged();

      imprimirResultado(
        "Configuración aplicada correctamente.",
        true
      );
    } catch (error) {
      imprimirResultado(
        "Error al aplicar configuración: " + error.message,
        false
      );

      setStatus(
        "Error al aplicar configuración: " + error.message
      );
    }
  });
}