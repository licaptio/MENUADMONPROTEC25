import { store } from "../state/store.js";
import { $, escapeHtml, fmtNum, fmtCelda } from "../utils/format.js";
import { fechaCorta } from "../utils/dates.js";

function filtro() { return String($("busqueda")?.value || "").trim().toLowerCase(); }
function pasaFiltroPivot(item) { const q = filtro(); if (!q) return true; return [item.codigo, item.nombre].some(v => String(v || "").toLowerCase().includes(q)); }
function pasaFiltroDetalle(item) { const q = filtro(); if (!q) return true; return [item.tipo,item.codigo,item.nombre,item.folio,item.destino,item.entrega,item.recibe,item.proveedor,item.alias_pivot,item.rfc_emisor,item.razon_social_emisor].some(v => String(v || "").toLowerCase().includes(q)); }

function proveedoresPorFecha(fecha) {
  const proveedores = store.registrosEntradasSemana.filter(x => x.fecha === fecha).map(x => String(x.alias_pivot || x.proveedor || x.entrega || "").trim()).filter(Boolean);
  return [...new Set(proveedores)].join(" / ");
}


export function pintarTabla() { store.vistaActual === "detalle" ? pintarDetalle() : pintarPivotPorSemana(); }

function pintarPivotPorSemana() {
const tabla = $("tabla");
if (!tabla) {
  console.error("No existe #tabla en el HTML");
  return;
}
  const thead = tabla.querySelector("thead");
  const tbody = tabla.querySelector("tbody");
  const tfoot = tabla.querySelector("tfoot");
  const rows = store.registrosPivot.filter(pasaFiltroPivot);
  const fechasConEntrada = store.fechasColumnas.filter(f => store.registrosEntradasSemana.some(x => x.fecha === f));

  thead.innerHTML = `<tr><th class="left">Código</th><th class="left">Nombre</th><th>INVINI<br>SEMANA</th>${store.fechasColumnas.map(f => {
    const tieneEntrada = fechasConEntrada.includes(f);
    return `${tieneEntrada ? `<th class="entrada-head">${fechaCorta(f)}<br>ENTRADA<br><small>${escapeHtml(proveedoresPorFecha(f))}</small></th>` : ""}<th class="salida-head">${fechaCorta(f)}<br>SALIDA</th>`;
  }).join("")}<th>TOTAL<br>ENTRADAS</th><th>TOTAL<br>SALIDAS</th><th>EXISTENCIA<br>FINAL</th></tr>`;

  tbody.innerHTML = rows.map(r => `<tr><td class="left codigo">${escapeHtml(r.codigo)}</td><td class="left">${escapeHtml(r.nombre)}</td><td class="cantidad">${fmtNum(r.inviniSemana)}</td>${store.fechasColumnas.map(f => {
    const entrada = Number(r.entradasPorFecha[f] || 0);
    const salida = Number(r.salidasPorFecha[f] || 0);
    const tieneEntrada = fechasConEntrada.includes(f);
    return `${tieneEntrada ? `<td class="entrada-col ${entrada ? "cantidad" : ""}">${fmtCelda(entrada)}</td>` : ""}<td class="salida-col ${salida ? "cantidad" : ""}">${fmtCelda(salida)}</td>`;
  }).join("")}<td class="cantidad entrada-total">${fmtNum(r.totalEntradasSemana)}</td><td class="cantidad">${fmtNum(r.totalSalidasSemana)}</td><td class="cantidad">${fmtNum(r.existenciaFinalSemana)}</td></tr>`).join("");

  const totalEntradasPorFecha = {}, totalSalidasPorFecha = {};
  store.fechasColumnas.forEach(f => { totalEntradasPorFecha[f] = 0; totalSalidasPorFecha[f] = 0; });
  rows.forEach(r => store.fechasColumnas.forEach(f => { totalEntradasPorFecha[f] += Number(r.entradasPorFecha[f] || 0); totalSalidasPorFecha[f] += Number(r.salidasPorFecha[f] || 0); }));
  const totalInvini = rows.reduce((s, r) => s + Number(r.inviniSemana || 0), 0);
  const totalEntradas = rows.reduce((s, r) => s + Number(r.totalEntradasSemana || 0), 0);
  const totalSalidas = rows.reduce((s, r) => s + Number(r.totalSalidasSemana || 0), 0);
  const totalFinal = rows.reduce((s, r) => s + Number(r.existenciaFinalSemana || 0), 0);

  tfoot.innerHTML = `<tr><td class="left" colspan="2">TOTAL</td><td>${fmtNum(totalInvini)}</td>${store.fechasColumnas.map(f => {
    const tieneEntrada = fechasConEntrada.includes(f);
    return `${tieneEntrada ? `<td class="entrada-col">${fmtNum(totalEntradasPorFecha[f])}</td>` : ""}<td class="salida-col">${fmtNum(totalSalidasPorFecha[f])}</td>`;
  }).join("")}<td>${fmtNum(totalEntradas)}</td><td>${fmtNum(totalSalidas)}</td><td>${fmtNum(totalFinal)}</td></tr>`;
}


function pintarDetalle() {
  const tabla = $("tabla");
  if (!tabla) {
    console.error("No existe #tabla en el HTML");
    return;
  }

  const thead = tabla.querySelector("thead");
  const tbody = tabla.querySelector("tbody");
  const tfoot = tabla.querySelector("tfoot");
  const rows = store.registrosDetalleMovimientoSemana.filter(pasaFiltroDetalle);
  const totalEntradas = rows.filter(x => x.tipo === "ENTRADA").reduce((s, x) => s + Number(x.cantidad || 0), 0);
  const totalSalidas = rows.filter(x => x.tipo === "SALIDA").reduce((s, x) => s + Number(x.cantidad || 0), 0);
  thead.innerHTML = `<tr><th>Tipo</th><th>Fecha</th><th class="left">Folio</th><th class="left">Destino / Proveedor</th><th class="left">Entrega / Emisor</th><th class="left">Recibe / Usuario</th><th>Partida</th><th class="left">Código</th><th class="left">Nombre</th><th>Cantidad</th></tr>`;
  tbody.innerHTML = rows.map(r => `<tr><td>${escapeHtml(r.tipo)}</td><td>${escapeHtml(r.fecha)}</td><td class="left">${escapeHtml(r.folio)}</td><td class="left">${escapeHtml(r.destino)}</td><td class="left">${escapeHtml(r.entrega)}</td><td class="left">${escapeHtml(r.recibe)}</td><td>${r.partida}</td><td class="left codigo">${escapeHtml(r.codigo)}</td><td class="left">${escapeHtml(r.nombre)}</td><td class="cantidad">${fmtNum(r.cantidad)}</td></tr>`).join("");
  tfoot.innerHTML = `<tr><td class="left" colspan="9">TOTAL ENTRADAS SEMANA</td><td>${fmtNum(totalEntradas)}</td></tr><tr><td class="left" colspan="9">TOTAL SALIDAS SEMANA</td><td>${fmtNum(totalSalidas)}</td></tr>`;
}

export function cambiarVista(vista) {
  store.vistaActual = vista;
  $("tabResumen").classList.toggle("active", vista === "resumen");
  $("tabDetalle").classList.toggle("active", vista === "detalle");
  $("tabConfig")?.classList.toggle("active", vista === "config");
  $("viewData")?.classList.toggle("hidden", vista === "config");
  $("viewConfig")?.classList.toggle("hidden", vista !== "config");
  if (vista !== "config") pintarTabla();
}
