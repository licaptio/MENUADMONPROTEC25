export function fechaISOLocal(date) {
  const yyyy = date.getFullYear();
  const mm = String(date.getMonth() + 1).padStart(2, "0");
  const dd = String(date.getDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

export function hoyISO() { return fechaISOLocal(new Date()); }

export function crearFechaLocal(fechaISO) {
  const [yyyy, mm, dd] = String(fechaISO).split("-").map(Number);
  return new Date(yyyy, mm - 1, dd);
}

export function sumarDias(fechaISO, dias) {
  const d = crearFechaLocal(fechaISO);
  d.setDate(d.getDate() + dias);
  return fechaISOLocal(d);
}

export function normalizarFecha(valor) {
  if (!valor) return "";
  if (typeof valor === "string") {
    const v = valor.trim();
    const m1 = v.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
    if (m1) return `${m1[3]}-${m1[2]}-${m1[1]}`;
    const m2 = v.match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (m2) return `${m2[1]}-${m2[2]}-${m2[3]}`;
    return v.substring(0, 10);
  }
  if (valor && typeof valor.toDate === "function") return fechaISOLocal(valor.toDate());
  if (valor && typeof valor.seconds === "number") return fechaISOLocal(new Date(valor.seconds * 1000));
  return String(valor).trim();
}

export function fechaCorta(fechaISO) {
  if (!fechaISO || !fechaISO.includes("-")) return fechaISO || "";
  const [yyyy, mm, dd] = fechaISO.split("-");
  return `${dd}/${mm}/${String(yyyy).slice(-2)}`;
}

export function obtenerSemanaActualInput() {
  const hoy = new Date();
  const fecha = new Date(hoy.getFullYear(), hoy.getMonth(), hoy.getDate());
  const dia = fecha.getDay();
  const jueves = new Date(fecha);
  jueves.setDate(fecha.getDate() + (4 - (dia || 7)));
  const inicioAnio = new Date(jueves.getFullYear(), 0, 1);
  const semana = Math.ceil((((jueves - inicioAnio) / 86400000) + 1) / 7);
  return `${jueves.getFullYear()}-W${String(semana).padStart(2, "0")}`;
}

export function obtenerRangoDomingoSabadoDesdeWeek(valorWeek, fechaInicioMinima) {
  if (!valorWeek) return { inicio: fechaInicioMinima, fin: sumarDias(fechaInicioMinima, 6) };
  const [anioTexto, semanaTexto] = valorWeek.split("-W");
  const anio = Number(anioTexto);
  const semana = Number(semanaTexto);
  const enero4 = new Date(anio, 0, 4);
  const diaSemana = enero4.getDay() || 7;
  const lunesSemana1 = new Date(enero4);
  lunesSemana1.setDate(enero4.getDate() - diaSemana + 1);
  const lunes = new Date(lunesSemana1);
  lunes.setDate(lunesSemana1.getDate() + (semana - 1) * 7);
  const domingo = new Date(lunes);
  domingo.setDate(lunes.getDate() - 1);
  const sabado = new Date(domingo);
  sabado.setDate(domingo.getDate() + 6);
  let inicio = fechaISOLocal(domingo);
  let fin = fechaISOLocal(sabado);
  if (inicio < fechaInicioMinima) inicio = fechaInicioMinima;
  if (fin < inicio) fin = inicio;
  return { inicio, fin };
}

export function crearFechasSemana(inicio, fin) {
  const fechas = [];
  let actual = inicio;
  while (actual <= fin) {
    fechas.push(actual);
    actual = sumarDias(actual, 1);
  }
  return fechas;
}
