export const $ = (id) => document.getElementById(id);

export function normalizarCodigo(valor) {
  const s = String(valor ?? "").trim();
  if (!s) return "";
  const soloDigitos = s.replace(/\D/g, "");
  if (!soloDigitos) return s.toLowerCase();
  return soloDigitos.replace(/^0+/, "") || "0";
}

export function escapeHtml(text) {
  return String(text ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

export function fmtNum(n) {
  return Number(n || 0).toLocaleString("es-MX", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

export function fmtCelda(n) {
  const num = Number(n || 0);
  if (!num) return "";
  return fmtNum(num);
}
