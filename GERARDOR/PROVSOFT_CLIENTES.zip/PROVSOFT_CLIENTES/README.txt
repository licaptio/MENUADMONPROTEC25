PROVSOFT_CLIENTES

1) Edita assets/js/firebase-config.js
   - Cambia apiKey por la real.

2) Publica la carpeta en hosting o abre con servidor local.
   Recomendado:
   npx serve PROVSOFT_CLIENTES

3) Funciones incluidas:
   - Buscar cliente por id o nombre.
   - Ver ficha.
   - Editar datos básicos.
   - Subir documentos ilimitados al bucket gs://clientes-provsoft-pdd.
   - Registrar documentos en subcolección DOCUMENTOS.
   - Ver/eliminar documentos.
   - Ver membresía con QR basado en idCliente.

4) Rutas:
   Firestore:
   /CLIENTES/PDD031204KL5/CLIENTES/{idCliente}
   /CLIENTES/PDD031204KL5/CLIENTES/{idCliente}/DOCUMENTOS/{documentoId}

   Storage:
   gs://clientes-provsoft-pdd/clientes/{idCliente}/documentos/{categoria}/{archivo}


VERSION v7:
- Se agregó expediente rápido dentro del modal de ficha del cliente.
- Desde la ficha se pueden seleccionar archivos, tomar foto, subir, ver, descargar y eliminar documentos.
- Reutiliza la subcolección DOCUMENTOS y el bucket clientes-provsoft-pdd.
