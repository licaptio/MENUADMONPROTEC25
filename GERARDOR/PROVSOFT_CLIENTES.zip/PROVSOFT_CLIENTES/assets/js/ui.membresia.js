const $ = (id) => document.getElementById(id);

export function pintarMembresia(cliente) {
  const panel = $("membresiaPanel");
  if (!cliente) {
    panel.innerHTML = "<p>Selecciona un cliente para ver su membresía.</p>";
    return;
  }
  const idCliente = String(cliente.idCliente || cliente.id);
  const vence = cliente.fechaVencimientoMembresia?.toDate ? cliente.fechaVencimientoMembresia.toDate().toLocaleDateString("es-MX") : "";
  panel.innerHTML = `
    <div class="member-card">
      <img src="./assets/img/logo.jfif" alt="Proveedora" />
      <div class="member-name">${cliente.nombre || "SIN NOMBRE"}</div>
      <div class="member-id">SOCIO ${idCliente}</div>
      <div>Estatus: ${cliente.membresiaActiva ? "ACTIVA" : "INACTIVA"}</div>
      <div>Vigencia: ${vence}</div>
      <div>Puntos: ${cliente.puntos ?? 0}</div>
      <div id="qrCliente" class="qr-box"></div>
    </div>
    <div><button id="btnImprimirMembresia">Imprimir / guardar</button></div>
  `;
  new QRCode($("qrCliente"), { text: idCliente, width: 190, height: 190 });
  $("btnImprimirMembresia").onclick = () => window.print();
}
